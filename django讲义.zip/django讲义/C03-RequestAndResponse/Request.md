
## 一、客户端传递请求参数的几种方式

1. 通过 **URL路径**（`path`）传递，例如：`http://127.0.0.1:8000/news/1/2`，两个参数：`新闻类别id` 和 `页码`　
2. 通过 `query string 查询字符串`传递
	1. 例如：`http://127.0.0.1:8000/news?category=1&page=2`
	2. 关于URL格式： `schema://host[:port][path][?query-string][#anchor]`
3. 通过 `body 请求体`传递，又可根据传递的数据格式，分为:
	1. 键值对：`category=1&page=2`
	2. 表单数据: 
	3. 非表单数据(json, xml)

 		   {"category": 1, "page": 2}

			<news>
			    <category>1</category>
			    <page>2</page>
			</news>

4. 通过 **`http` 协议请求头**（`header`）传递

<br/>

## 二、获取请求参数

### 1. 获取查询字符串

一、需求

获取URL地址 `http://127.0.0.1:8000/news2?category=1&page=2` 中的查询字符串的值

二、代码参考

```
# url配置
url(r'^news2$', views.news2),

# 视图函数
def news2(request):
    category = request.GET.get('category')
    page = request.GET.get('page')

	# ?category=1&page=2&a=3&a=4
	# a = request.GET.getlist('a')  # 一键多值通过 getlist 获取

    text = '获取查询字符串：<br/> category=%s, page=%s' % (category, page)
    return HttpResponse(text)
```

**重要：查询字符串不区分请求方式，即使客户端通过POST方式发起请求，依然可以通过request.GET获取请求中的查询字符串数据。**

<br/>

### 2. 获取请求体数据

请求体数据格式不固定，可以是表单类型字符串，可以是JSON字符串，可以是XML字符串，应区别对待。

可以发送请求体数据的请求方式有`POST`、`PUT`、`PATCH`、`DELETE`。

Django对`POST`、`PUT`、`PATCH`、`DELETE`请求方式开启了CSRF安全防护，为方便测试，可以在`settings.py`文件中注释掉CSRF中间件，关闭`CSRF`防护

![注释CSRF中间件](/imgs/django-017.png)

<br/>

### 2.1 获取表单数据 Form Data (键值对)

前端发送的表单或键值对类型的请求体数据，可以通过request.POST属性获取

```
# url配置
url(r'^news3$', views.news3),

# 视图函数
def news3(request):
    category = request.POST.get('category')
    page = request.POST.get('page')

 	# 一键多值通过从POST中用 getlist 获取
	# ?category=1&page=2&a=3&a=4
	# a = request.POST.getlist('a') 

    text = '获取body中的键值对:<br/>　category=%s, page=%s' % (category, page)
    return HttpResponse(text)
```

**重要：request.POST只能用来获取POST方式的请求体表单数据或键值对数据。如果为非post请求提交的请求体数据，或者是请求体数据类型为非表单或非键值对数据，则需要通过`request.body`属性获取提交的数据后，再自己手动解析**


### 2.2 非表单类型 Non-Form Data

非表单类型的请求体数据，Django无法自动解析，可以通过request.body属性获取最原始的请求体数据，自己按照请求体格式（JSON、XML等）进行解析。`request.body`返回bytes类型。

例如获取请求体中的json数据: `{"category": 1, "page": 2}`

```python
# url配置
url(r'^news4$', views.news4),

import json
def news4(request):
    # 获取json字符串
    json_str = request.body
    json_str = json_str.decode()  # python3.6 无需执行此步

    # 解析json
    dict_data = json.loads(json_str)
    category = dict_data.get('category')
    page = dict_data.get('page')

    text = '获取body中的json数据:　category=%s, page=%s' % (category, page)
    return HttpResponse(text)
```

<br/>

### 3. 获取请求头数据 

可以通过**request.META**属性获取请求头headers中的数据，**request.META为字典类型**。

常见的请求头如：（[官方文档参考](https://yiyibooks.cn/xx/Django_1.11.6/ref/request-response.html)）

- `CONTENT_LENGTH` – The length of the request body (as a string).
- `CONTENT_TYPE` – The MIME type of the request body.
- `HTTP_ACCEPT` – Acceptable content types for the response.
- `HTTP_ACCEPT_ENCODING` – Acceptable encodings for the response.
- `HTTP_ACCEPT_LANGUAGE` – Acceptable languages for the response.
- `HTTP_HOST` – The HTTP Host header sent by the client.
- `HTTP_REFERER` – The referring page, if any.
- `HTTP_USER_AGENT` – The client’s user-agent string.
- `QUERY_STRING` – The query string, as a single (unparsed) string.
- `REMOTE_ADDR` – The IP address of the client.
- `REMOTE_HOST` – The hostname of the client.
- `REMOTE_USER` – The user authenticated by the Web server, if any.
- `REQUEST_METHOD` – A string such as `"GET"` or `"POST"`.
- `SERVER_NAME` – The hostname of the server.
- `SERVER_PORT` – The port of the server (as a string).


注意： 

- 获取自定义的请求头属性值时，**需要添加前缀 `HTTP_` 并转成大写**，作为键来获取值 

示例：

```python
def news4(request):
	# 获取请求头数据：a=1&b=2
	print(request.META.get('HTTP_A'), request.META.get('HTTP_B'))
```
